const o="/static/icons/chevron-down.svg";export{o as _};
