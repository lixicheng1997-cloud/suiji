const s="/static/icons/chevron-right.svg";export{s as _};
